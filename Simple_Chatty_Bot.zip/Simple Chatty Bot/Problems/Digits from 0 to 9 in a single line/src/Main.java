class Main {
    public static void main(String[] args) {
        for (int i = 9; i >= 0; i--) {
            String num = "" + i;
            System.out.print(num + " ");
        }
    }
}